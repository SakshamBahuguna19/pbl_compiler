def add(a, b):
    return a + b

x = 6
y = 10
print(add(x, y))
