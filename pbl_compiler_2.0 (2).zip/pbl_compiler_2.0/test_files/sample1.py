def add(x, y):
    return x + y

a = 5
b = 15
print(add(a, b))
