# This is a comment

def add(a, b):
    """This adds two numbers."""
    result = a + b
    return result

x = 10  # variable x
y = 20  # variable y
print(add(x, y))
