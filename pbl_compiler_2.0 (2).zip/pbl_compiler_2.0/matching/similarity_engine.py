# matching/similarity_engine.py

from matching.lexical_matcher import compare_files_lexically
from matching.semantic_matcher import compute_semantic_similarity

def compute_combined_similarity(code1: str, code2: str, lexical_weight: float = 0.5) -> float:
    """
    Computes the combined similarity score using both lexical and semantic matchers.

    Args:
        code1 (str): First source code.
        code2 (str): Second source code.
        lexical_weight (float): Weight for lexical score. (0 to 1)

    Returns:
        float: Combined similarity score (0 to 100)
    """
    lexical_score = compare_files_lexically(code1, code2)
    semantic_score = compute_semantic_similarity(code1, code2)

    combined_score = (lexical_score * lexical_weight) + (semantic_score * (1 - lexical_weight))
    return round(combined_score, 2)
