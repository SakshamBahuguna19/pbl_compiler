def add(var_0, var_1):
    var_2 = var_0 + var_1
    return var_2
var_3 = 10
var_4 = 20
print(add(var_3, var_4))