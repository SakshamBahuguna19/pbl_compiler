# test_cleaner.py
from preprocessing.cleaner import clean_code

clean_code('sample_input.py', 'cleaned_output.py')
